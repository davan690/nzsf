## Data for the analysis protected species captures
These data were prepared for the analysis of protected species captures. Fishing effort,
observer data, and protected species capture data have been groomed for this purpose, and
the reported captures and fishing effort may differ from the values reported
elsewhere.

##Licence
Data are made available for reuse by the [Ministry for Primary Industries](https://www.mpi.govt.nz), 
under a creative commons 3.0 New Zealand attribution licence, following the recommendations of [NZGOAL](https://ict.govt.nz/guidance-and-resources/open-government/nzgoal). 
This licence allows the data to be used for any other purpose and republished, provided that attribution is given to the source.

##Data files
###protected_species_captures.csv
A comma-delimited text file containing a row for each capture of
a seabird, marine mammal, turtle, reported
by Government fisheries observers, where the capture was the
result of fishing activity.  The data are restricted to fishing
that occurred within the New Zealand Exclusive Economic Zone,
and to fishing by trawl, longline, set net and purse seine methods.
Captures include animals that were
killed, as well as those that were released alive.
The data in this file cover the period 2002&ndash;03 to
2017&ndash;18.

####Fields

- **fishing_year** the fishing year of the capture. Fishing years run from 1 October to 30 September.

- **datetime** the date and time of the capture. All times are in New Zealand Standard Time.

- **taxon** the best idenification of the capture. The names given are common names. 

- **status** whether the animal was alive or dead

- **identification** how the identification was made (necropsy: by necropsy of the dead animal; photograph: from
    an expert inspection of a photograph of the capture; imputation: imputed by correcting the observer code using
    necropsy and photographic identifications of other captures with the same observer identification; as reported
    by the observer).
    
- **capture_method** how the animal was caught. In many cases, the capture method was not recorded by the observer 
    (net: caught in a net; hook: caught  by a hook; line: caught during surface longline fishing;              
        warp or door: caught on a trawl warp or on the door;  unknown: capture method reported by the observer as unknown;
    other: capture method reported by the observer as 'other'; tangled: tangled by the line during longline fishing; 
    mitigation device: caught by a seabird mitigation device; paravane: caught on the paravane or by the paravane wire;
    net restrictor: caught on the net restrictor that is used during some scampi fishing)

    
- **method** the fishing method (surface longline; bottom longline; trawl; set net; or purse seine)  

- **target** the target species reported by the fisher  

- **vessel_size** the length class of the vessel (a range in m) 

- **area** the area of the fishing    

- **version** a version number that identifies this data set 

- **latitude** the latitude of the capture (decimal degrees). The positions are accurate to within 
    0.05 degrees (around 6 km). The latitude of the captures was first rounded to the nearest 0.05
    degrees, and a random jitter of plus or minus 0.025 degrees was then added. This ensures that the
    captures data meets Ministry for Primary Industries anonymisation requirements (the positions do 
    not precisely refelect the location of fishing events).

- **longitude** the longitude of the capture (decimal degrees). The longitude has been jittered in the
    same way as the latitude.

###species_fishery_year_summary.csv
Comma-delimited text summarising the number of observed captures in
each fishing year and fishery.

####Fields
- **year** the fishing year 

- **method** the method of the fishing

- **fishery** the target fishery of the fishing. The fisheries are albacore longline, bigeye longline, bluenose longline, deepwater trawl, flatfish set net,
    flatfish trawl, grey mullet set net, hake trawl, hapuka longline, hoki trawl, inshore trawl, jack mackerel trawl, ling longline, ling trawl,
    mackerel purse seine, middle depth trawl,
    minor bottom longline,minor purse seine,
    minor set net, minor surface longline,
    scampi trawl, shark set net,
    skipjack purse seine, snapper longline,
    southern bluefin longline, southern blue whiting trawl,
    squid trawl, swordfish longline.

- **tows** the number of tows (for trawl fishing)
- **hooks** the number of hooks (for longline fishing)
- **net_length** the length of the net (m) (for set net fishing)
- **sets** the number of sets for purse seine fishing
- **percent_observed** the percentage of fishing that was observed

For the following species and species groups the table lists the number of captures in the corresponding year and fishery:

- **white_capped_albatross** New Zealand white-capped albatross
- **salvins_albatross** Salvin's albatross
- **southern_bullers_albatross** Southern Buller's albatross
- **other_albatrosses** All other albatross species
- **white_chinned_petrel** White-chinned petrel
- **sooty_shearwater** Sooty shearwater
- **other_birds** All other birds
- **new_zealand_sea_lion** New Zealand sea lion
- **new_zealand_fur_seal** New Zealand fur seal
- **other_seals** All other pinnipeds (e.g., leopard seal, elephant seal, unidentified seals)
- **common_dolphin** Common dolphin
- **other_dolphins** Other delphinids
- **pilot_whale** Pilot whale
- **whales** All other cetaceans
- **hectors_dolphin** Hector's dolphin
- **turtles** All turtles

###effort_position_summary.csv

Comma-delimited file summarising fishing effort
for trawl, longline, set net, and purse seine fishing within 0.2 degree cells. These are
the data that were used to generate the maps seen on the PSC website.
The data are grouped by fishing method and target species, and are
the annual average fishing effort over the three most recent fishing years to 2017&ndash;18
(1 October 2015 to 30 September 2018).
Not all fishing effort data was reported by fishers with a location, and 
some fishing effort was given an imputed position (based on randomly sampling
fishing by similar vessels in the same fishery and area). There is a column that records
the percentage of effort which was given an imputed position. Fishing effort that
did not meet Ministry for Primary Industries data anonymisation
requirements (three or more vessels or entities within each group), was grouped without 
a position. Fish species that were targeted by fewer than three vessels or
clients over the period were grouped as "other species".

####Fields

- **method** the method of the fishing
- **target** the fisher-declared target fish species or species groups (common names as used by MPI)
- **location_status** for missing locations: "unknown", if no location data were available and location could not be imputed, or "censored" if fewer than three vessels or entities were fishing within the 0.2 degree cell over the three years
- **latitude** latitude of the center of the 0.2 degree cell
- **longitude** longitude of the center of the 0.2 degree cell
- **tows** the average number of tows per year (for trawl fishing)
- **hooks** the average number of hooks per year (for longline fishing).
- **net_length** the mean length of the net (m) per year (for set net fishing)
- **sets** the average number of sets per year for purse seine fishing
- **percent_imputed** the percentage of fishing with imputed locations
- **percent_observed** the percentage of fishing that was observed


